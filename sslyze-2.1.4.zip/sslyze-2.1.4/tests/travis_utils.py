import os

IS_RUNNING_ON_TRAVIS = 'TRAVIS' in os.environ
